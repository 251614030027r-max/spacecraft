"""Automatic factual packaging/publication after the frozen gate chain stops."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

TOPIC=Path(__file__).resolve().parent.parent
ROOT=TOPIC.parents[1]
SCI=Path('D:/py/DRL2_T1_O')
LOG=SCI/'logs/t1o_v2'
COLLAB=ROOT/'过程文件/协作/Git工作树'
DEST=TOPIC/'交付构建/证据'
REL='docs/collaboration/lower/handoffs/t1o_v2_gates_20261017'
LATEST=ROOT/'上层交付/最新'
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def copy(p,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);assert sha(p)==sha(d)
def git(*args):return subprocess.check_output(['git','-C',str(COLLAB),*args],text=True,encoding='utf-8').strip()
assert not DEST.exists(),'Existing delivery: inspect, do not overwrite'
DEST.mkdir(parents=True)
with (TOPIC/'记录/DELIVERY.lock').open('x') as f:f.write(now())
terminal=load(TOPIC/'记录/STATE.json')
chain=load(LOG/'CHAIN.json') if (LOG/'CHAIN.json').exists() else {'stages':[]}
sources=[]
for p in sorted(LOG.rglob('*')) if LOG.exists() else []:
    if p.is_file() and p.suffix.lower()!='.zip':
        d=DEST/'science/t1o_v2'/p.relative_to(LOG);copy(p,d);sources.append(dict(source=str(p),stored=d.relative_to(DEST).as_posix(),sha256=sha(p)))
chain_log=SCI/'logs/t1o_v2_chain.log'
if chain_log.exists():copy(chain_log,DEST/'science/t1o_v2_chain.log')
zero=SCI/'logs/t1_o_tcpf_20261017/or3_zero'
models=[]
if zero.exists():
    for p in sorted(zero.rglob('*')):
        if not p.is_file():continue
        if p.suffix.lower()=='.zip':
            with zipfile.ZipFile(p) as z:
                data=json.loads(z.read('data'))
                assert data.get('_n_updates',0)==0,'Zero-step model unexpectedly updated'
                assert data.get('num_timesteps',0)<=1,'Unauthorized training budget'
            models.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,num_timesteps=data.get('num_timesteps'),updates=data.get('_n_updates')))
        else:copy(p,DEST/'science/or3_zero'/p.relative_to(zero))
write(DEST/'MODEL_SHA256.json',models)
for dirname in ('记录','日志','脚本'):
    for p in sorted((TOPIC/dirname).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:copy(p,DEST/'execution'/dirname/p.relative_to(TOPIC/dirname))
for name in ('SHA256SUMS','gate_a.json','README.md','per_opening.csv'):
    p=SCI/'evidence/T1O_V2/gate_a'/name
    if p.exists():copy(p,DEST/'provenance/gate_a_archive'/name)
copy(COLLAB/'docs/collaboration/upper/run_orders/T1_O_V2_GATES_LOCAL_20261017.md',DEST/'provenance/RUN_ORDER.md')
for name in ('t1o_p2_discovery_openings.json','t1o_p2_confirmation_openings.json','t1o_p2_development_openings.json'):
    copy(SCI/'experiments'/name,DEST/'provenance'/name)
write(DEST/'SOURCE_MANIFEST.json',sources)
stages=chain.get('stages',[])
failed=[s['stage'] for s in stages if not s.get('pass')]
stop=failed[0] if failed else (stages[-1]['stage'] if stages else terminal['phase'])
lines=['# T1-O V2本机门控：事实交付（2026-10-17）','',
 '科学冻结`d3902a9dd62dbef6cb318e36ff4c2527d7340ec9`；执行单第2版collab `08a8b66`。本轮仅Gate A存档复用及B/C/零步/E串联门控，不含Gate D或正式训练。旧T1-L-S正式长训取消，旧T1-L/v4资产保持只读。','',
 f'停止位置：**{stop}**。控制器终态：`{terminal["phase"]}`。遇首个FAIL后未继续后续科学阶段；未生成的结果明确记为未执行，不补值。','',
 '## 阶段原始判定与关键数','']
for s in stages:lines+=['### '+s['stage']+'：'+('PASS' if s.get('pass') else 'FAIL'),'','```json',json.dumps(s,ensure_ascii=False,indent=2),'```','']
seen={s['stage'] for s in stages}
for name in ('B','C','C_zero_step','E'):
    if name not in seen:lines.append('- '+name+'：未执行或未完成判定，以原始文件和技术日志为准。')
lines+=['','## 核验、资源与边界','',
 '- 本机6物理核、12逻辑线程；按执行单W=5，Normal优先级，OMP/MKL/OPENBLAS各1。冻结Gate B入口不接收workers，内部默认4路，其余受chain传入W控制。没有为提高利用率修改冻结代码或追加参数。',
 '- Gate A只允许上层Linux存档复用，不是本机重算；实际归档SHA和160回合计数以execution/记录/GATE_A_ARCHIVE_RECEIPT.json为准。若该回执尚未产生，表示在准入阶段已停止。保留上层判据与敏感开局事实，不把源数据称为同机复现。',
 '- 指定测试、开局SHA、依赖逐文件比较、磁盘与阶段墙钟见execution/记录；完整控制器状态如下。墙钟与资源采样不冒充OS累计CPU时间，不作实时性声明。',
 '- 仅如链条到达C_zero_step才按冻结代码生成1步模型，learning_starts=1000，无梯度更新；模型ZIP仅列SHA和路径，不上传。',
 '- 未传--reproduce-gate-a或--through-d，未新增任何科学参数、规则或开局；未访问正式块300000–999999。',
 '- 无人工重判或失败后扩展。Gate C在32独立确认开局机械判定，不用发现集成绩替代。Gate A的单开局敏感性、是否固定κ/v_in及后续GO均交上层/研究层决定。',
 '- 本轮原始Gate A回合、实际产生的Gate B/C/零步/E JSON、完整chain log、模型manifest、命令/测试/资源回执随独立ZIP；模型不含在内。','',
 '```json',json.dumps(terminal,ensure_ascii=False,indent=2),'```','']
for name in ('state_rule.json','gate_b.json','gate_c.json','zero_step.json','gate_e_calibrate.json','gate_e.json'):
    p=LOG/name
    if p.exists():lines+=['## '+name,'','```json',json.dumps(load(p),ensure_ascii=False,indent=2),'```',''] if name not in ('gate_b.json',) else ['','Gate B逐开局分支原始数据见science/t1o_v2/gate_b.json。','']
(DEST/'RESULT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
sums=[f'{sha(p)}  {p.relative_to(DEST).as_posix()}' for p in sorted(DEST.rglob('*')) if p.is_file()]
(DEST/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
package=TOPIC/'T1O_V2_GATES_LOCAL.zip'
assert not package.exists()
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(DEST.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(DEST).as_posix())
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None and not any(n.lower().endswith('.zip') for n in z.namelist())
    for line in sums:
        h,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==h
receipt=dict(phase='BUILT_SHA_VERIFIED',utc=now(),stop_stage=stop,package=str(package),package_bytes=package.stat().st_size,sha256=sha(package),models_uploaded=False,models_hashed=len(models),files=len(sums),gate_d_run=False,full_training_started=False)
write(TOPIC/'记录/PUBLICATION_STATE.json',receipt)
# Synchronize before making any changes in the collaboration checkout.
helper=ROOT/'过程文件/协作/脚本/协作助手.py'
subprocess.run([sys.executable,'-B',str(helper),'sync'],check=True)
archive=ROOT/'上层交付/历史/T1_L_FINAL_20261017_before_T1O'
assert LATEST.resolve().is_relative_to(ROOT.resolve()) and archive.resolve().is_relative_to(ROOT.resolve())
assert not archive.exists()
archive.mkdir(parents=True)
archived={}
for p in list(LATEST.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(LATEST);h=sha(p);dest=archive/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(p),str(dest));assert sha(dest)==h;archived[rel.as_posix()]=h
write(archive/'ARCHIVE_SHA256_RECEIPT.json',dict(utc=now(),files=archived))
(archive/'HISTORY_NOTE.md').write_text('# 历史：T1-L三臂40k最终交付\n\n2026-10-17在T1-O V2门控交付后归档；原README和ZIP内容不变，逐文件SHA已核验。证据68680eb，核验回执3165ac8。\n',encoding='utf-8')
remote_dest=COLLAB/REL
remote_dest.mkdir(parents=True,exist_ok=True)
for directory in (LATEST,remote_dest):
    for name in ('RESULT.md','SHA256SUMS.txt','SOURCE_MANIFEST.json','MODEL_SHA256.json'):copy(DEST/name,directory/name)
    (directory/'PACKAGE_SHA256.txt').write_text(f'{receipt["sha256"]}  {package.name}\n本机路径：{package}\n',encoding='utf-8')
    if package.stat().st_size<=50_000_000:copy(package,directory/package.name)
    (directory/'README.md').write_text(f'# T1-O V2本机门控交付\n\n停止阶段：{stop}；阶段判定和关键数见RESULT.md，完整原始结果见独立ZIP；超过50MB时ZIP仅保留本机路径和SHA。发布核验见DELIVERY_RECEIPT.json。未执行Gate D或正式训练。\n',encoding='utf-8')
    write(directory/'DELIVERY_RECEIPT.json',receipt)
for name in ('CHAIN.json','state_rule.json','gate_c.json','zero_step.json','gate_e.json'):
    if (LOG/name).exists():copy(LOG/name,remote_dest/name)
current_path=COLLAB/'docs/collaboration/CURRENT.json';current=load(current_path)
current.update(t1o_topic='t1o_v2_gates',t1o_scientific_commit='d3902a9dd62dbef6cb318e36ff4c2527d7340ec9',t1o_run_order='docs/collaboration/upper/run_orders/T1_O_V2_GATES_LOCAL_20261017.md',t1o_phase='gates_stopped_pending_upper_review',t1o_stop_stage=stop,t1o_handoff=REL+'/RESULT.md',t1o_package_sha256=receipt['sha256'],t1o_gate_d_started=False,t1o_training_started=False,t1o_updated_utc=now())
write(current_path,current)
idx=COLLAB/'docs/collaboration/lower/README.md';s=idx.read_text(encoding='utf-8-sig');s=s.split('\n',1)[0]+f'\n\n**2026-10-17最新：** [T1-O V2本机门控](handoffs/t1o_v2_gates_20261017/RESULT.md)，停止阶段{stop}；只交事实，待上层核实。未执行Gate D或正式训练。\n\n'+s.split('\n',1)[1];idx.write_text(s,encoding='utf-8')
assert git('rev-parse','HEAD')==git('rev-parse','origin/collab/spacecraft')
changed=git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
assert all(p in ('docs/collaboration/CURRENT.json','docs/collaboration/lower/README.md') or p.startswith(REL+'/') for p in changed)
git('add','--','docs/collaboration/CURRENT.json','docs/collaboration/lower/README.md',REL)
if (remote_dest/package.name).exists():git('add','-f','--',REL+'/'+package.name)
git('commit','-m',f'Deliver frozen T1-O V2 local gates stopped at {stop}; no pilot training')
commit=git('rev-parse','HEAD');git('push','origin','HEAD:collab/spacecraft')
remote=git('ls-remote','origin','refs/heads/collab/spacecraft').split()[0];assert remote==commit
for p in remote_dest.iterdir():
    if p.is_file():
        b=subprocess.check_output(['git','-C',str(COLLAB),'show',f'{commit}:{p.relative_to(COLLAB).as_posix()}']);assert hashlib.sha256(b).hexdigest()==sha(p)
receipt.update(phase='PUBLISHED_VERIFIED',evidence_commit=commit,remote_commit=remote,git_blob_verified=True,verified_utc=now())
write(TOPIC/'记录/PUBLICATION_STATE.json',receipt)
write(LATEST/'DELIVERY_RECEIPT.json',receipt)
write(remote_dest/'DELIVERY_RECEIPT.json',receipt)
subprocess.run([sys.executable,'-B',str(helper),'publish','--message','Verify T1-O V2 gates evidence publication receipt'],check=True)
receipt_commit=git('rev-parse','HEAD');assert git('ls-remote','origin','refs/heads/collab/spacecraft').split()[0]==receipt_commit
receipt.update(publication_receipt_commit=receipt_commit)
write(TOPIC/'记录/PUBLICATION_STATE.json',receipt)
write(LATEST/'DELIVERY_RECEIPT.json',receipt)
write(TOPIC/'记录/STATE.json',{**terminal,'phase':'PUBLISHED_VERIFIED','publication_state':'记录/PUBLICATION_STATE.json','evidence_commit':commit,'no_further_scientific_tasks':True})
(ROOT/'上层交付/README.md').write_text('# 上层交付入口\n\n当前：[T1-O V2本机门控](最新/RESULT.md)，2026-10-17；完整证据、阶段原始判定和SHA见最新。旧T1-L最终包已原样哈希归档历史/T1_L_FINAL_20261017_before_T1O。本轮不包含Gate D或正式训练，等待上层核实与研究层决定。\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
