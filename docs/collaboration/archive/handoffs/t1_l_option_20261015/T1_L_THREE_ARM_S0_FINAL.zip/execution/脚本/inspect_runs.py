"""Single read-only inspection per scheduled turn; no launch/stop/Git actions."""
import datetime
import json
from pathlib import Path
import psutil

TOPIC = Path(__file__).resolve().parent.parent
PROJECT = TOPIC.parents[1]
NEW = Path('D:/py/DRL2_T1_L/logs/t1_l_option_20261015')
OLD = Path('D:/py/DRL2_T1/logs/t1')
LATEST = TOPIC / '记录/NIGHT_CHECK_LATEST.json'

def load(p):
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding='utf-8-sig'))
    except (ValueError, OSError) as e:
        return {'read_error': str(e)}

def evaluations(run):
    result = {}
    for d in (run / 'dev_eval').glob('*'):
        if d.is_dir() and d.name.isdigit():
            result[d.name] = {'written': len(list(d.glob('[0-9]*.json'))), 'summary': load(d / 'summary.json')}
    return result

def tail_record(p):
    if not p.exists():
        return 0, None
    with p.open('rb') as f:
        f.seek(0, 2)
        length = f.tell()
        f.seek(max(0, length - 30000))
        for line in reversed(f.read().splitlines()):
            try:
                return length, json.loads(line)
            except ValueError:
                continue
    return length, None

previous = load(LATEST) or {}
state = load(TOPIC / '记录/STATE.json') or {}
entry = (PROJECT / '项目说明.md').read_text(encoding='utf-8-sig')
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
memory = psutil.virtual_memory()
result = {'utc': now, 'state_phase': state.get('phase'), 'memory_available_gb': memory.available / 1e9,
          'memory_percent': memory.percent, 'disk_free_gb': psutil.disk_usage('D:/').free / 1e9,
          'runs': {}, 'v4': {}, 'processes': []}
for arm in ('b2', 'n0', 'ndelta'):
    run = NEW / f'{arm}_s0'
    length, row = tail_record(run / 'decisions.jsonl')
    result['runs'][arm] = {'heartbeat': load(run / 'heartbeat.json'),
        'last_t': row.get('t') if row else None, 'bytes': length,
        'previous_t': previous.get('runs', {}).get(arm, {}).get('last_t'),
        'aborted': (run / 'ABORTED.json').exists(), 'abort_record': load(run / 'ABORTED.json'),
        'finished': load(run / 'finished.json'), 'eval': evaluations(run),
        'checkpoints': sorted(p.name for p in (run / 'checkpoints').glob('*.zip')),
        'calibration_5k': load(run / 'checkpoints/ndelta_5000_delta_calibration.json') if arm == 'ndelta' else None}
final = load(PROJECT / '过程文件/T1v4首轮配对训练_20261015/记录/DELIVERY_FINAL_STATE.json')
result['v4_final_delivery'] = final
if not final or final.get('phase') != 'PUBLISHED_VERIFIED':
    for arm in ('m0', 'm2'):
        run = OLD / f't1v4_{arm}_s0'
        result['v4'][arm] = {'finished': load(run / 'finished.json'), 'eval': evaluations(run)}
modules = {'train.train_t1_option', 'experiments.t1_l_eval', 'experiments.t1_dev_eval'}
for p in psutil.process_iter(['name', 'cmdline']):
    try:
        cmd = p.info['cmdline'] or []
        if p.info['name'].lower().startswith('python') and modules.intersection(cmd):
            result['processes'].append({'pid': p.pid, 'ppid': p.ppid(), 'cmd': cmd,
                                        'priority': int(p.nice()), 'rss': p.memory_info().rss})
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
LATEST.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
compact = {k: result[k] for k in ('utc', 'state_phase', 'memory_available_gb', 'memory_percent', 'disk_free_gb')}
compact['project_entry_read'] = bool(entry)
compact['runs'] = {a: {k: r[k] for k in ('last_t', 'previous_t', 'heartbeat', 'aborted', 'finished', 'checkpoints')}
                   | {'calibration_5k': ({k: v for k,v in r['calibration_5k'].items() if not isinstance(v,list)}
                      | {'probes': len(r['calibration_5k'].get('ratios',[]))}) if r['calibration_5k'] else None}
                   | {'eval': {n: {'written': e['written'], 'summary_complete': isinstance(e['summary'], dict) and e['summary'].get('episodes') == 16} for n,e in r['eval'].items()}}
                   for a,r in result['runs'].items()}
compact['v4'] = {a: {'finished': r['finished'], 'eval': {n: {'written': e['written'], 'summary_complete': isinstance(e['summary'], dict) and e['summary'].get('episodes') == 16}
                    for n,e in r['eval'].items()}} for a,r in result['v4'].items()}
compact['live_module_counts'] = {m: sum(m in p['cmd'] for p in result['processes']) for m in modules}
compact['all_new_idle'] = all(p['priority'] == int(psutil.IDLE_PRIORITY_CLASS) for p in result['processes']
                             if 'experiments.t1_dev_eval' not in p['cmd'])
print(json.dumps(compact, ensure_ascii=False))
