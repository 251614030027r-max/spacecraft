param([ValidateSet(0,1,2)][int]$Seed=0,[switch]$Reviewed)
$ErrorActionPreference='Stop'
if (-not $Reviewed) { throw '先阅读中断核查包，并确认按原冻结方案重训；确认后使用 -Reviewed。' }
$science='D:/py/DRL2_T1'
$python='D:/py/DRL2/.venv/Scripts/python.exe'
$record='C:/Users/35884/Documents/Spacecraft/过程文件/T1首轮_20261012/记录'
$active=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'train\.train_t1' })
if ($active.Count) { throw '有训练进程仍在运行；不重复启动。' }
if ($Seed -gt 0) {
    $prior=$Seed-1
    foreach ($m in 'm0','m1') {
        $prev="t1_${m}_s${prior}"; if ($prior -eq 0) { $prev+='_r1' }
        $f="$science/logs/t1/$prev/finished.json"
        if (!(Test-Path -LiteralPath $f)) { throw "上一对未完整结束：$prev" }
        if ((Get-Content -LiteralPath $f -Raw | ConvertFrom-Json).decisions -ne 20000) { throw '上一条没有完成20k。' }
    }
}
Set-Location -LiteralPath $science
$head=(& git rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $head -ne 'f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c') { throw '冻结提交不符。' }
$dirty=@(& git status --porcelain)
if ($LASTEXITCODE -ne 0 -or $dirty.Count) { throw '科学树有改动；不得allow-dirty。' }
$env:OMP_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'
$names=@{}; foreach ($m in 'm0','m1') {
    $name="t1_${m}_s${Seed}"; if ($Seed -eq 0) { $name+='_r1' }; $names[$m]=$name
    if (Test-Path -LiteralPath "$science/logs/t1/$name") { throw "目标目录已存在：$name；保留，不覆盖。" }
}
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$probe="$record/RESTART_PROBE_s${Seed}_$stamp.json"
& $python -B -m experiments.t1_throughput_probe --workers 2 --method m1 --decisions 40 --output $probe
if ($LASTEXITCODE -ne 0) { throw '资源探针失败，未启动训练。' }
$p=Get-Content -LiteralPath $probe -Raw | ConvertFrom-Json
$one=Get-Content -LiteralPath "$science/logs/t1/_probe/w1_m1.json" -Raw | ConvertFrom-Json
$memory=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024
if ($p.s_per_decision_max -gt 1.5*$one.s_per_decision_max -or ($p.peak_rss_mb_max+900)*2*1MB -ge 0.7*$memory) { throw '资源门未通过，未启动训练。' }
if ((Get-PSDrive D).Free -lt 10GB) { throw '磁盘不足10GB。' }
$receipt=@()
foreach ($m in 'm0','m1') {
    $name=$names[$m]
    $args="-B -m train.train_t1 --method $m --steps 20000 --seed $Seed --run-name $name --log-root logs/t1"
    $p=Start-Process -FilePath $python -ArgumentList $args -WorkingDirectory $science -WindowStyle Hidden -RedirectStandardOutput "$science/logs/t1/_console/$name.out" -RedirectStandardError "$science/logs/t1/_console/$name.err" -PassThru
    $receipt+=[ordered]@{kind='training';run=$name;pid=$p.Id;arguments=$args;utc=[DateTime]::UtcNow.ToString('o')}
    $receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$record/RESTART_LAUNCH_s${Seed}_$stamp.json" -Encoding utf8
}
Start-Sleep -Seconds 10
foreach ($m in 'm0','m1') {
    $name=$names[$m]
    if (!(Test-Path -LiteralPath "$science/logs/t1/$name/manifest.json")) { throw "训练未创建manifest：$name；查stderr，另一条不要停止或重复启动。" }
    $args="-B -m experiments.t1_dev_eval --watch logs/t1/$name --openings experiments/t1_dev_openings_295000.json"
    $p=Start-Process -FilePath $python -ArgumentList $args -WorkingDirectory $science -WindowStyle Hidden -RedirectStandardOutput "$science/logs/t1/_console/eval_$name.out" -RedirectStandardError "$science/logs/t1/_console/eval_$name.err" -PassThru
    $receipt+=[ordered]@{kind='evaluation_watch';run=$name;pid=$p.Id;arguments=$args;utc=[DateTime]::UtcNow.ToString('o')}
    $receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$record/RESTART_LAUNCH_s${Seed}_$stamp.json" -Encoding utf8
}
Write-Output "种子$Seed已从零成对启动。回执：$record/RESTART_LAUNCH_s${Seed}_$stamp.json。原始中断目录未改动。"
