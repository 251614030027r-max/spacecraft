﻿$ErrorActionPreference='Continue'
Set-Location -LiteralPath 'D:\py\DRL2_T1_L'
$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1';$env:OPENBLAS_NUM_THREADS='1'
(Get-Process -Id $PID).PriorityClass='Idle'
Add-Type -Namespace Win32 -Name ConsoleCheck -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);'
$h=[Win32.ConsoleCheck]::GetConsoleWindow()
@{shell_pid=$PID;utc=[DateTime]::UtcNow.ToString('o');console_hwnd=$h.ToInt64();visible=[Win32.ConsoleCheck]::IsWindowVisible($h)} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\pure_WINDOW.json' -Encoding utf8
& 'D:\py\DRL2\.venv\Scripts\python.exe' -B -m experiments.t1_gstar_probe run --row pure --task t1l --seeds 297000,297002,297003,297004,297005,297007,297008,297010,297012,297013,297015,297016,297018,297020,297024,297051 --output-dir 'logs/t1_l_option_20261015/pure' 1> 'logs/t1_l_option_20261015/pure.out' 2> 'logs/t1_l_option_20261015/pure.err'
$exitcode=$LASTEXITCODE
@{shell_pid=$PID;exit_code=$exitcode;finished_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\pure_RECEIPT.json' -Encoding utf8