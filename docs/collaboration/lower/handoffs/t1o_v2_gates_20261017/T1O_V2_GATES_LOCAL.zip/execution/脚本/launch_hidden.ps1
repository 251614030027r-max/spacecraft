﻿$ErrorActionPreference='Continue'
Set-Location -LiteralPath 'D:/py/DRL2_T1_O'
$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1';$env:OPENBLAS_NUM_THREADS='1'
(Get-Process -Id $PID).PriorityClass='Normal'
Add-Type -Namespace T1OV2 -Name ConsoleCheck -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);'
$h=[T1OV2.ConsoleCheck]::GetConsoleWindow()
@{shell_pid=$PID;utc=[DateTime]::UtcNow.ToString('o');visible=[T1OV2.ConsoleCheck]::IsWindowVisible($h)} | ConvertTo-Json | Set-Content -LiteralPath 'C:/Users/35884/Documents/Spacecraft/过程文件/T1O_V2本机门控_20261017/记录/WINDOW.json' -Encoding utf8
& 'D:/py/DRL2/.venv/Scripts/python.exe' -B 'C:/Users/35884/Documents/Spacecraft/过程文件/T1O_V2本机门控_20261017/脚本/execute.py' 1> 'C:/Users/35884/Documents/Spacecraft/过程文件/T1O_V2本机门控_20261017/日志/controller.out' 2> 'C:/Users/35884/Documents/Spacecraft/过程文件/T1O_V2本机门控_20261017/日志/controller.err'
@{shell_pid=$PID;exit_code=$LASTEXITCODE;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath 'C:/Users/35884/Documents/Spacecraft/过程文件/T1O_V2本机门控_20261017/记录/EXIT.json' -Encoding utf8
