"""Build a self-contained factual delivery; originals and model ZIPs remain in place."""
import csv
import datetime as dt
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path('C:/Users/35884/Documents/Spacecraft')
TOPIC=ROOT/'过程文件/T1-L三臂支线_20261015'
SCI=Path('D:/py/DRL2_T1_L')
BASE=SCI/'logs/t1_l_option_20261015'
DEST=TOPIC/'最终构建/证据'
ARMS=('b2','n0','ndelta')
MARKS=(0,2000,5000,10000,15000,20000,25000,30000,35000,40000)
COMMIT='166244bd4d08713473e17354626f10e40b496e01'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def copy(p,d):
    d.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,d)
    assert sha(p)==sha(d),p
assert not DEST.exists(),'Existing build: inspect instead of overwrite'
assert load(TOPIC/'记录/DELIVERY_FINAL_STATE.json')['phase']=='FINAL_CHECKS_READY_FOR_PACKAGING'
seeds=load(SCI/'experiments/t1l_dev_openings_297000.json')['seeds']
assert len(seeds)==len(set(seeds))==16
for a in ARMS:
    run=BASE/(a+'_s0')
    assert load(run/'manifest.json')['code_commit']==COMMIT
    assert load(run/'manifest.json')['code_dirty'] is False
    assert load(run/'finished.json')['decisions']==40000
    assert not (run/'ABORTED.json').exists()
    assert load(run/'stats_final.json')['decisions']==40000
    reload=load(run/'reload.json')
    assert len(reload)==11 and all(x['finite'] and len(x['action'])==3 for x in reload.values())
    for m in MARKS:
        directory=run/'dev_eval'/str(m)
        assert load(directory/'summary.json')['episodes']==16
        assert {int(p.stem) for p in directory.glob('[0-9]*.json')}==set(seeds)
DEST.mkdir(parents=True)
sources=[]
for p in sorted(BASE.rglob('*')):
    if not p.is_file() or p.suffix.lower()=='.zip':continue
    rel=p.relative_to(BASE)
    target=DEST/'science'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    original_sha=sha(p)
    if p.suffix=='.jsonl':
        target=target.with_suffix('.jsonl.gz')
        with p.open('rb') as inp,target.open('wb') as out:
            with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:shutil.copyfileobj(inp,gz)
        with gzip.open(target,'rb') as f: assert hashlib.sha256(f.read()).hexdigest()==original_sha
    else:copy(p,target)
    sources.append(dict(source=str(p),stored=target.relative_to(DEST).as_posix(),source_sha256=original_sha,stored_sha256=sha(target),source_bytes=p.stat().st_size))
for dirname in ('记录','日志','脚本','交付脚本'):
    for p in sorted((TOPIC/dirname).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.name not in ('DELIVERY_FINAL_STATE.json',):copy(p,DEST/'execution'/dirname/p.relative_to(TOPIC/dirname))
order=ROOT/'过程文件/协作/Git工作树/docs/collaboration/upper/run_orders/T1_L_OPTION_THREE_ARM_20261015.md'
copy(order,DEST/'provenance/RUN_ORDER.md')
copy(SCI/'experiments/t1l_dev_openings_297000.json',DEST/'provenance/t1l_dev_openings_297000.json')
write(DEST/'SOURCE_MANIFEST.json',sources)
models=[]
for a in ARMS:
    run=BASE/(a+'_s0')
    for p in sorted([*(run/'checkpoints').glob('*.zip'),run/'final.zip']): models.append(dict(arm=a,path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
with (DEST/'MODEL_SHA256.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=['arm','path','bytes','sha256']);writer.writeheader();writer.writerows(models)
assert len(models)==33
d=load(BASE/'readout_final.json')
rows=[]
for a in ARMS:
    for m in MARKS:
        s=d['arms'][a]['marks'][str(m)]['outcome']
        rows.append(dict(arm=a,checkpoint=m,**s))
with (DEST/'LEARNING_CURVE.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
paired=[]
for m in MARKS:
    for seed in seeds:
        row=dict(checkpoint=m,opening=seed)
        for a in ARMS:
            s=load(BASE/(a+'_s0')/'dev_eval'/str(m)/f'{seed}.json')
            for key in ('event','discounted_return','time_s','delta_v_m_s'): row[a+'_'+key]=s[key]
        paired.append(row)
with (DEST/'PAIRED_OPENINGS.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)
lines=['# T1-L三臂种子0：40k最终事实交付（2026-10-17）','',
 '本轮为旧T1-L（非T1-L-S）。三臂各40,000真实2s步、全部10检查点×16开发开局，共480回合；均正常完成，无ABORTED。三目录stats检查及33个模型文件的有限动作重载通过。新T1-L-S已按用户最新指令暂停，未测速、未训练；本包不包含新线成果。','',
 '## 版本、配置与证据范围','',
 f'- 科学冻结：`{COMMIT}`；执行单第2版collab `8aa038a`，原文见provenance/RUN_ORDER.md。每臂manifest确认code_dirty=false。',
 '- 本机Windows，共享Python3.12环境；n_envs=1，种子0，UTD4，lr1e-4，batch256，buffer300000，网络256×3，gamma0.999，tau0.001；OMP/MKL/OPENBLAS线程均1；lambda_mc=.03、lambda_eq=.1；obs34。完整任务、接口和环境版本以各manifest为准。',
 '- B2每2s审议；N0/NΔ通常每6s、计划事件后提前。NΔ保留3000步预热、2500–3000只读梯度测量，一次冻结相对项权重，此后单次更新上限为TD梯度10%。',
 '- 开发文件SHA `0fd6c137f8aca1558f349d29713b7bb75d86452adc2db448b62c1efafe9376f3`；16固定开局按几何分层。本轮不是多种子或独立正式评估，未访问300000–999999。',
 '- 65项本机指定准入测试通过，六套规则与Pure各16，共112基线回合；同机、同任务基线原始JSON均随包。模型仅列SHA和本机路径，不上传模型。','',
 '## 全部检查点','',
 '|臂|步数|捕获/16|超时|unsafe|平均折扣回报|Δv m/s|时间s（失败300）|',
 '|---|---:|---:|---:|---:|---:|---:|---:|']
for row in rows:lines.append('|{arm}|{checkpoint}|{capture}|{timeout}|{unsafe}|{mean_discounted_return:.9f}|{mean_delta_v_m_s:.9f}|{mean_time_s_fail_as_300:.6f}|'.format(**row))
lines+=['','## 本轮固定基线（全部同机）','','|参照|捕获/16|回报|Δv m/s|时间s（失败300）|','|---|---:|---:|---:|---:|']
for name,s in d['references'].items():lines.append(f"|{name}|{s['capture']}|{s['mean_discounted_return']:.9f}|{s['mean_delta_v_m_s']:.9f}|{s['mean_time_s_fail_as_300']:.6f}|")
lines+=['','强固定参照按预注册回报、捕获数、较低Δv顺序在六规则中选择，为rule:earliest_k1.0_v0.02；这是开发集选择，不作为独立验证。Pure为本轮T1-L的11/16、回报2.496030926581，不能换成旧T1的0.9079。','',
 '## 40k逐开局配对摘要','', '|臂|比较|平均回报差|中位回报差|更好/更差开局|捕获差|','|---|---|---:|---:|---:|---:|']
for a in ARMS:
    mark=d['arms'][a]['marks']['40000']
    for key in ('vs_0k','vs_rule_k1.0_v0.02','vs_pure'):
        s=mark[key];lines.append(f"|{a}|{key}|{s['mean_return_diff']:.9f}|{s['median_return_diff']:.9f}|{s['openings_better']}/{s['openings_worse']}|{s['capture_diff']}|")
for name,marks in d['between_arms'].items():
    s=marks['40000'];lines.append(f"|{name}|臂间40k|{s['mean_return_diff']:.9f}|{s['median_return_diff']:.9f}|{s['openings_better']}/{s['openings_worse']}|{s['capture_diff']}|")
lines+=['','逐检查点完整配对统计见science/readout_final.json；逐开局回报、事件、时间、Δv见PAIRED_OPENINGS.csv，全部原始轨迹及动作/Q审计保留于science/*_s0/dev_eval/。此处只报告观察差，不作显著性或方法有效判定。','',
 '## 校准、反事实、梯度和Critic审计','']
t=d['arms']['ndelta']['training']
for key in ('delta_calibration','delta','cf_by_kind','cf_valid_differences_by_kind'):
    lines+=['### '+key,'','```json',json.dumps(t.get(key),ensure_ascii=False,indent=2),'```','']
lines+=['实际梯度占比来自日志中抽样诊断点，不是每次更新的完整人口统计；目标5%为一次校准目标，不保证全程恒等5%。10%浮点容差按原始数据保留。continue与descent无反事实样本，不误报为开局择时增益。','',
 '### 三臂Critic与动作审计','']
for a in ARMS:
    mark=d['arms'][a]['marks']['40000'];train=d['arms'][a]['training']
    lines+=['#### '+a,'','```json',json.dumps(dict(training_audit=train.get('critic_audit'),eval40_decisions=mark['decisions'],eval40_critic=mark['critic']),ensure_ascii=False,indent=2),'```','']
lines+=['Q−G是软Q/策略后续与实际回报口径的诊断差，不直接等同动作排序误差，也不据此单独判定因果根因。完整1k行为、审议比例、首次延迟/锚点、入口速度与κ、邻域Q诊断在冻结readout和原始fix_stats内。','',
 '## 成本、执行偏离与限制','', '|臂|实际完成UTC|墙钟h|墙钟s/真实步|','|---|---|---:|---:|']
for a in ARMS:
    train=d['arms'][a]['training'];h=train['heartbeat'];finish=load(BASE/(a+'_s0')/'finished.json')
    lines.append(f"|{a}|{finish['finished_utc']}|{h['wall_s']/3600:.6f}|{train['wall_s_per_step']:.6f}|")
lines+=['','- 上述是各运行墙钟，包含运行时资源竞争；既不相加冒充总历时，也不冒充OS累计CPU小时。前段保护v4并采用Idle，资源/窗口/吞吐回执随包。',
 '- 20k中间交付未按门槛及时独立发布：用户10月16日停用定时跟进并接手监视后，本次直接最终收口；不追溯伪造当时的快照。所有20k完整原始结果已随本包交付。',
 '- 本轮只一粒种子和16开发开局。超过Pure包含架构贡献；对零步的变化与NΔ−N0另列。不能据此宣称RL不可替代、稳定泛化或MPC反馈已被证明有效。',
 '- 不挑最好检查点，所有0/2k/5k至40k均提供。训练日志事件比例与确定性开发成绩分开报告。未新增评估、重训、调权或续训。',
 '- 本包不含后续64开局/T1-R；那属于被用户暂缓的新T1-L-S执行单。','',
 '## 文件结构与核验','',
 '- science/：本轮科学原始结果、所有检查点侧车、基线、manifest/环境版本、冻结readout/stats/reload、console与运行回执。JSONL采用gzip无损压缩，原始文件不移动。',
 '- execution/：本主题准入、资源、启动、进程、测试与最终核验记录及外部脚本。provenance/：本执行单与开局文件。',
 '- SOURCE_MANIFEST.json同时列原文件SHA和包内SHA；MODEL_SHA256.csv列33个模型，只提供哈希。SHA256SUMS.txt覆盖包内所有其他文件。',
 '- 旧v4只作为历史固定引用：证据commit2242f1bc0602dbb356fa5f4ad9cb9ed41e386c85，ZIP SHA3715fa780c484ee1e0d21916ae1326b2989f549891c9930137ce2fbea15dff76；其40k M0/M2回报−3.7308403373/4.828302688，与本轮任务/接口不同，不作同条件归因。未将旧ZIP嵌入本包。']
report='\n'.join(lines)+'\n'
(DEST/'RESULT.md').write_text(report,encoding='utf-8')
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,1,figsize=(8,7),sharex=True)
    for a in ARMS:
        marks=d['arms'][a]['marks'];axes[0].plot(MARKS,[marks[str(m)]['outcome']['mean_discounted_return'] for m in MARKS],marker='o',label=a)
        axes[1].plot(MARKS,[marks[str(m)]['outcome']['capture'] for m in MARKS],marker='o',label=a)
    axes[0].axhline(d['references']['rule_k1.0_v0.02']['mean_discounted_return'],ls='--',color='gray',label='Strong fixed rule')
    axes[0].set_ylabel('Mean discounted return');axes[1].set_ylabel('Captures / 16');axes[1].set_xlabel('Real 2 s transitions')
    axes[1].set_ylim(0,16.5)
    for ax in axes:ax.grid(alpha=.25);ax.legend()
    fig.tight_layout();fig.savefig(DEST/'LEARNING_CURVE.png',dpi=150);plt.close(fig)
except ImportError: pass
sums=[]
for p in sorted(DEST.rglob('*')):
    if p.is_file():sums.append(f'{sha(p)}  {p.relative_to(DEST).as_posix()}')
(DEST/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
package=TOPIC/'T1_L_THREE_ARM_S0_FINAL.zip'
assert not package.exists()
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(DEST.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(DEST).as_posix())
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert not any(n.endswith('.zip') for n in z.namelist())
    for line in sums:
        h,name=line.split('  ',1); assert hashlib.sha256(z.read(name)).hexdigest()==h,name
receipt=dict(phase='BUILT_SHA_VERIFIED',utc=dt.datetime.now(dt.timezone.utc).isoformat(),scientific_commit=COMMIT,package=str(package),package_bytes=package.stat().st_size,sha256=sha(package),models_uploaded=False,models_hashed=33,development_episodes=480,baseline_episodes=112,files=len(sums),source_files=len(sources),interim_deviation='Not separately delivered; final contains all marks',new_branch='HELD_BY_USER_NOT_STARTED')
write(TOPIC/'记录/DELIVERY_FINAL_STATE.json',receipt)
print(json.dumps(receipt,ensure_ascii=False))
