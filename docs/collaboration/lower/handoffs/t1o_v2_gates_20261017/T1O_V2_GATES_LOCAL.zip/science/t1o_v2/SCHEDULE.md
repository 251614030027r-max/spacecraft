# 本机调度

UTC 2026-10-17T07:58:09.779423+00:00；CPU AMD Ryzen 5 5600H with Radeon Graphics；物理核6、逻辑线程12，按执行单物理核−1选择W=5。Normal优先级，OMP/MKL/OPENBLAS=1；全部新后台窗口隐藏。

冻结chain给C/零步/E传入W；Gate B入口不暴露workers参数，内部冻结默认4个工作进程，因此B实际4路，不改代码或追加禁用参数。墙钟为资源记录，不是实时性声明或OS累计CPU时间。
