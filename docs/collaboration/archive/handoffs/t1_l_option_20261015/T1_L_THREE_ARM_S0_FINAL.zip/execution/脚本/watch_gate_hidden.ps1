﻿$ErrorActionPreference='Continue'
(Get-Process -Id $PID).PriorityClass='Idle'
& 'D:\py\DRL2\.venv\Scripts\python.exe' -B 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\脚本\start_watchers_when_safe.py' 1> 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\日志\watch_gate.out' 2> 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\日志\watch_gate.err'