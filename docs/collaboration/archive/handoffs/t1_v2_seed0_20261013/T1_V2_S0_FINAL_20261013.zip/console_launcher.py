"""Foreground launcher/console observer; frozen scientific code is unchanged."""
import argparse,datetime,json,os,pathlib,subprocess,threading,time,sys
ROOT=pathlib.Path('D:/py/DRL2_T1')
TOPIC=pathlib.Path(__file__).resolve().parent.parent
RECORD=TOPIC/'记录'
PYTHON='D:/py/DRL2/.venv/Scripts/python.exe'
NAME='t1v2_m1_s0_r1'
RUN=ROOT/'logs/t1'/NAME
EXPECTED='78eb63c22615c9672c43338be4cec54da713812c'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['train','watch']);args=parser.parse_args()
    env=os.environ.copy()
    for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:env[key]='1'
    env['PYTHONIOENCODING']='utf-8';env['PYTHONUNBUFFERED']='1'
    if args.mode=='train':
        import psutil
        for p in psutil.process_iter(['pid','cmdline']):
            c=p.info['cmdline'] or []
            if 'train.train_t1' in c:raise SystemExit('Training is already active. Do not duplicate.')
        if RUN.exists():raise SystemExit('Run directory exists. Do not overwrite or resume.')
        assert json.loads((RECORD/'ADMISSION_STATE.json').read_text(encoding='utf-8-sig'))['state']=='PASSED'
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==EXPECTED
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
        subprocess.run(['powercfg','/change','standby-timeout-ac','0'],check=True)
        subprocess.run(['powercfg','/change','hibernate-timeout-ac','0'],check=True)
        argv=['-m','train.train_t1','--method','m1','--steps','60000','--seed','0','--n-envs','6','--run-name',NAME,'--log-root','logs/t1','--checkpoint-freq','5000']
    else:
        deadline=time.time()+120
        while not (RUN/'manifest.json').exists() and time.time()<deadline:
            print('Waiting for the training manifest...',flush=True);time.sleep(10)
        if not (RUN/'manifest.json').exists():raise SystemExit('Training manifest missing. Start train in terminal 1 first.')
        manifest=json.loads((RUN/'manifest.json').read_text())
        assert manifest['code_commit']==EXPECTED
        argv=['-m','experiments.t1_dev_eval','--watch',str(RUN),'--openings','experiments/t1_dev_openings_295000.json','--checkpoints','0,5000,10000,15000,20000,25000,30000,35000,40000,45000,50000,55000,60000','--workers','3','--stop-on-plateau']
    lock=RECORD/f'PYCHARM_{args.mode.upper()}_R1.lock'
    with lock.open('x',encoding='utf-8') as f:f.write(datetime.datetime.now(datetime.timezone.utc).isoformat())
    command=[PYTHON,'-u','-B',*argv]
    process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    receipt={'mode':args.mode,'run':NAME,'pid':process.pid,'command':command,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launcher':'pycharm_foreground_no_external_windows'}
    target=RECORD/f'PYCHARM_{args.mode.upper()}_R1_RECEIPT.json'
    target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{args.mode.upper()} running in this terminal; run={NAME}; PID={process.pid}',flush=True)
    def stream(pipe,suffix):
        with (ROOT/f'logs/t1/_v2/{args.mode}_r1.{suffix}').open('wb') as log:
            for line in iter(pipe.readline,b''):
                log.write(line);log.flush();print(line.decode('utf-8',errors='replace'),end='',flush=True)
    for pipe,suffix in [(process.stdout,'out'),(process.stderr,'err')]:threading.Thread(target=stream,args=(pipe,suffix),daemon=True).start()
    previous=None
    try:
        while process.poll() is None:
            if args.mode=='train':
                try:
                    h=json.loads((RUN/'heartbeat.json').read_text())
                    if h['decisions']!=previous:
                        previous=h['decisions'];rate=h['decisions']/max(h['wall_s'],1)*3600
                        print(f"[TRAIN] decisions={h['decisions']}/60000  wall={h['wall_s']/3600:.2f}h  rate={rate:.0f}/h  finite={h['parameters_finite']}",flush=True)
                except (FileNotFoundError,json.JSONDecodeError):pass
            time.sleep(5)
    except KeyboardInterrupt:
        print('Interrupted by user. This run must not be resumed.',flush=True)
        if process.poll() is None:process.terminate()
        process.wait(timeout=15)
    receipt['exit_code']=process.returncode;receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{args.mode.upper()} exited: {process.returncode}',flush=True)
    raise SystemExit(process.returncode or 0)

if __name__=='__main__':main()
