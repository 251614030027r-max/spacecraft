# 执行单：T1_ROUND1_M0M1_20261012（下层本机执行）

**状态：已授权待执行。**（2026-10-12 修订：第 2 节改为现场实际前提——DRL2 在 `4795910`、F01 结果已归档；新增 2.0 协作分叉的整合方式。冻结提交与授权范围不变。） 授权范围：本机准入，以及六组 M0/M1 训练与开发评估。独立正式评估**不在**授权范围内。

**人类授权来源：** 用户 2026-10-12 在上层会话中的审查结论，原话摘录：

> 接受本轮有条件 GO。接受 M1 约25%的额外计算开销，不再修改 G★，冻结科学提交 f36ac77 及全部训练与评估配置。按现有 RUN_ORDER 执行本机代码核对、16开发开局规则基准复算、吞吐与资源探针；任何异常先上报。本机准入通过后，先启动种子0的 M0/M1 成对完整20k训练。两条均完成5k工程健康检查后，再按资源条件释放种子1、2。不因早期成绩调整奖励、网络、门控、训练预算或种子……完成后提交六组完整证据、配对学习曲线和规则基准比较，再决定是否进入独立正式评估。下层仅执行冻结方案，不自行修改研究方法。

**依据：** 上层审批记录 [`T1_ROUND1_PRETRAIN_GO_NO_GO_20261012.md`](../T1_ROUND1_PRETRAIN_GO_NO_GO_20261012.md)。

---

## 0. 写给从旧阶段过来的下层：先读这一节

你上次的工作停在 F01（学习停止头 / 价值交接，`f2f8169`）。之后发生的变化：

1. **研究主线换成 T1 任务**：快速三维翻滚目标的六自由度预捕获。F01 的停止头、交接、`w2.36_r15` 等内容全部**不再使用**。背景必读两份协作文件：[`../../HANDOFF.md`](../../HANDOFF.md)，以及 [`../../RESEARCH_EVOLUTION_AND_COUPLING_DESIGN_20261012.md`](../../RESEARCH_EVOLUTION_AND_COUPLING_DESIGN_20261012.md)。
2. **本轮正式比较三行：** Pure MPC、M0、M1。
   - **M0** = SAC 输出到达时机 τ 与下降节奏 κ → G★ 规划器生成可执行参考 → 共享 MPC 执行。
   - **M1** = M0 + 训练期的"门控 MPC 反事实"critic 辅助目标。环境、观测、动作、奖励、MPC 都与 M0 完全相同，唯一的差别在 critic 损失。
   - **本轮只训练 M0 和 M1**。Pure 和无学习规则只作对照，不需要训练。
3. **代码全部在科学分支提交 `f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c` 里**，新文件主要是：
   - `env/t1_*.py`
   - `train/train_t1.py`、`train/t1_m1.py`
   - `experiments/t1_dev_eval.py`、`t1_learning_readout.py`、`t1_throughput_probe.py`、`t1_pretrain_checks.py`、`t1_frozen_config.py`
4. **你不做任何方法决策。** 遇到本单没有写到的情况，停下来上报。

---

## 1. 冻结内容

所有配置都在代码里，本单不改任何值。

| 项 | 值 |
|---|---|
| 科学提交 | `f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c`（代码树与 `7b27e27` 相同，G★ 0.3.2） |
| 冻结配置全文 | `evidence/T1_pretrain_checks/frozen_config.json`，SHA-256 `4c302d9e3d993a328689992e68da04fbba2294787205a7361446f8fede950e02` |
| SAC | 256×3（ReLU），lr 1e-4，batch 256，buffer 3e5，τ 0.001，γ 0.999，熵系数 0.005（固定），learning_starts 1000，每决策 1 次更新 |
| M1 | λ 0.5；热身 15%（20k 下为 3000 次决策）；辅助损失按完整 batch 归一化；门控：生效 τ 差 ≥ 4 s，对照预测饱和 ≤ 0.5，全 2 s 预测窗无违规且无模式切换，QP 已解且松弛 ≤ 1e-3，末 4 s 禁用，执行分支误差 e_r ≤ 0.06、e_p ≤ 0.02 m、e_o ≤ 0.07 |
| 训练 | M0 和 M1 × 种子 0、1、2，每条 20000 次决策，从零开始；训练开局 = 10⁶·(seed+1) + 回合序号 |
| 开发评估 | `experiments/t1_dev_openings_295000.json`（16 个开局，SHA-256 `97f4d8f1f2ffdc952f0d90cb6fe95c5ae607d8281f0969935a97cfa2c9230b5f`）；在 5k/10k/15k/20k 检查点做确定性串行评估 |
| 学习效率判读 | `experiments/t1_learning_readout.py`：AUC（梯形面积 ÷ 15k）；首次达到规则水平 81.0895；按种子配对 |
| 开局隔离 | 训练 ≥ 10⁶；开发评估 295000–295054；R0 2900xx 和 R1 2910xx 不用；**正式测试块 300000 起本轮不得访问** |

---

## 2. 更新本地 Git 与环境（PowerShell）

### 2.0 协作分支的分叉（先处理，只动协作检出）

如果本地 `collab/spacecraft` 有未推送的提交（例如 F01 收口提交 `15b1f3a`），与远端分叉：

- 用**合并**整合，不变基、不改写、不丢弃本地提交，不强推：
  ```powershell
  git merge --no-ff origin/collab/spacecraft
  git push origin collab/spacecraft
  ```
- 若发生冲突，按文件处理：
  - `PROJECT_STATE.md`、`upper/` 下的文件：以远端版本为准（上层维护）；
  - `CURRENT.json`、`lower/` 下的文件：以本地版本为准（下层维护），准入后再按 T1 更新 `CURRENT.json`；
  - `registry/*.csv`：两边的行全部保留，只合并、不删除；
  - 其他文件冲突：停下上报。

### 2.1 确认现场

现场已知（2026-10-12 下层核实）：`D:\py\DRL2` 已按整理执行单完成至 `4795910`；F01 旧结果已按整理执行单归档；受跟踪文件干净；无 Python 后台进程。**这就是本轮的正确前提，不需要回到 `f2f8169`，也不移动任何已归档的文件。**

```powershell
Get-Process python -ErrorAction SilentlyContinue | Format-Table Id, StartTime, Path   # 应无输出；若有，停下上报
```

### 2.2 新建独立的 T1 工作树（`D:\py\DRL2` 保持 `4795910` 不动）

```powershell
cd D:\py\DRL2
git status --porcelain --untracked-files=no      # 应无输出；记录
git fetch origin
git cat-file -t f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c    # 应输出 commit
git worktree add D:\py\DRL2_T1 f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c
cd D:\py\DRL2_T1
git log -1 --format=%H                            # 必须是 f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c
git status --porcelain                            # 必须无输出
```

**本轮的全部命令都在 `D:\py\DRL2_T1` 中执行。** 在六组训练全部结束之前，不得在这个工作树里切换、拉取、修改或提交。

### 2.3 Python 环境

依赖文件在 `4795910` 与 `f36ac77` 之间没有变化，沿用现有 Python 环境，**不升级、不降级任何包**。

```powershell
git diff --stat 4795910 f36ac77bc2dd328bcc6ec08bfa86e684f8e9ed8c -- requirements.txt requirements-mpc.txt requirements-dev.txt   # 应无输出
python --version
python -c "import cvxpy; print(cvxpy.__version__, cvxpy.installed_solvers())"   # 必须包含 CLARABEL
python -c "import psutil" ; if ($LASTEXITCODE -ne 0) { python -m pip install psutil }   # 只供探针测内存；安装要记录
$env:OMP_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"
mkdir logs\t1\_env, logs\t1\_console, logs\t1\_probe
python -m pip freeze > logs\t1\_env\pip_freeze.txt
```

**之后每次新开的 PowerShell 窗口，都要先进入 `D:\py\DRL2_T1`，再设置上面三个线程变量。**

---

## 3. 本机准入（必须全部通过才能启动训练）

```powershell
python -B -m pytest -q tests/test_t1.py tests/test_t1_gym.py tests/test_t1_counterfactual.py tests/test_t1_m1.py tests/test_t1_termination.py
python -B -m experiments.t1_frozen_config --output logs\t1\_env\frozen_config_local.json
python -B -m experiments.t1_dev_eval --policy rule:earliest --openings experiments/t1_dev_openings_295000.json --output-dir logs/t1/_rule_local
python -B -m experiments.t1_throughput_probe --workers 1 --method m1 --decisions 40 --output logs\t1\_probe\w1_m1.json
python -B -m experiments.t1_throughput_probe --workers 6 --method m1 --decisions 40 --output logs\t1\_probe\w6_m1.json
python -B -m experiments.t1_throughput_probe --workers 8 --method m1 --decisions 40 --output logs\t1\_probe\w8_m1.json
python -B -m experiments.t1_throughput_probe --workers 6 --method m0 --decisions 40 --output logs\t1\_probe\w6_m0.json
```

| 准入项 | 通过条件 |
|---|---|
| A 测试 | 全部通过 |
| B 冻结配置 | `frozen_config_local.json` 与 `evidence/T1_pretrain_checks/frozen_config.json` 只允许 `code_commit` 不同，并且 `code_dirty` 为 false |
| C 规则基准 | `logs/t1/_rule_local/summary.json` 为 16/16 捕获，平均折扣回报与 81.0895 相差 ≤ 0.5。这是跨机核对，**冻结的判读数字仍是 81.0895，不替换** |
| D 并发路数 N | 取满足以下两条的最大 N（≤ 8）：`s_per_decision_max(N) ≤ 1.5 × s_per_decision(1)`；`(peak_rss_mb_max + 900) × N <` 可用内存的 70%（900 MB = 训练进程的网络与 Replay，加评估监视进程）。只看资源，不看任何学习结果 |
| E 磁盘 | 剩余空间 ≥ 10 GB |

**交付：** 写 `lower/handoffs/t1_round1_20261012/ADMISSION.md`，内容包括：A–E 的结果、全部探针 JSON、`pip_freeze` 的路径、选定的 N 和预计墙钟（20000 × s_per_decision(N)，评估另计）。同时更新 `CURRENT.json`（topic 改为 `t1_round1`，`scientific_commit` 改为 f36ac77…）。

**A–E 全部通过，按第 4 节继续**（用户已授权准入后先启动种子 0）。**任何一项不通过，就停下上报，不要处理。**

---

## 4. 分批训练

### 4.1 批 1：种子 0 的 M0/M1 一对（每条都是完整 20k，不是短跑）

每条训练配一个评估监视进程，它会在 5k/10k/15k/20k 检查点出现时自动做开发评估。训练目录由脚本创建，目录已存在时脚本拒绝启动。

```powershell
Start-Process python -ArgumentList "-B -m train.train_t1 --method m0 --steps 20000 --seed 0 --run-name t1_m0_s0 --log-root logs/t1" -RedirectStandardOutput logs\t1\_console\t1_m0_s0.out -RedirectStandardError logs\t1\_console\t1_m0_s0.err -NoNewWindow
Start-Process python -ArgumentList "-B -m train.train_t1 --method m1 --steps 20000 --seed 0 --run-name t1_m1_s0 --log-root logs/t1" -RedirectStandardOutput logs\t1\_console\t1_m1_s0.out -RedirectStandardError logs\t1\_console\t1_m1_s0.err -NoNewWindow
Start-Process python -ArgumentList "-B -m experiments.t1_dev_eval --watch logs/t1/t1_m0_s0 --openings experiments/t1_dev_openings_295000.json" -RedirectStandardOutput logs\t1\_console\eval_m0_s0.out -RedirectStandardError logs\t1\_console\eval_m0_s0.err -NoNewWindow
Start-Process python -ArgumentList "-B -m experiments.t1_dev_eval --watch logs/t1/t1_m1_s0 --openings experiments/t1_dev_openings_295000.json" -RedirectStandardOutput logs\t1\_console\eval_m1_s0.out -RedirectStandardError logs\t1\_console\eval_m1_s0.err -NoNewWindow
```

训练脚本会拒绝在有改动的检出上运行。若它报 `refusing to train from a modified or unknown checkout`，停下上报，**不得**加 `--allow-dirty`。

### 4.2 5k 工程健康检查（两条都过 5000 次决策、5k 评估写出后）

| # | 检查项（只看工程健康，**不看成绩**） |
|---|---|
| 1 | 没有 `ABORTED.json`；`heartbeat.json` 中 `parameters_finite = true`，且 `decisions` 仍在增长 |
| 2 | `checkpoints\m0_5000_decisions.zip`、`m1_5000_decisions.zip` 存在，且下面的加载命令全部输出有限动作 |
| 3 | `dev_eval\5000\summary.json` 两个都在，各 16 个回合 |
| 4 | `episodes.jsonl` 中出现过终止事件；`decisions.jsonl` 在增长 |
| 5 | M1：`checkpoints\m1_5000_cf_stats.json` 在第 3000 次决策之后有非零的 `aux_loss`；`decisions.jsonl` 中出现 `"w": 1` |
| 6 | 实测 s/决策不超过探针估计的 1.5 倍 |

```powershell
# 第 2 项：加载两个 5k 检查点，各输出一个动作
python -B -c "import glob; from stable_baselines3 import SAC; from train.t1_m1 import M1SAC; from env.t1_gym import T1GStarEnv; e=T1GStarEnv(openings=[9100000]); o,_=e.reset(); [print(p, (M1SAC if '/m1_' in p.replace(chr(92),'/') else SAC).load(p, device='cpu').predict(o, deterministic=True)[0]) for p in sorted(glob.glob('logs/t1/t1_m*_s0/checkpoints/*_5000_decisions.zip'))]" > logs\t1\_console\reload_s0_5k.txt
# 跟踪项：先按完整行做日志快照（训练仍在写），再统计
python -B -c "import pathlib; [[(pathlib.Path('logs/t1/_snap5k')/r).mkdir(parents=True, exist_ok=True), [(pathlib.Path('logs/t1/_snap5k')/r/n).write_text(''.join(l for l in (pathlib.Path('logs/t1')/r/n).read_text().splitlines(True) if l.endswith(chr(10)))) for n in ('decisions.jsonl','episodes.jsonl')]] for r in ('t1_m0_s0','t1_m1_s0')]"
python -B -m experiments.t1_pretrain_checks stats logs/t1/_snap5k/t1_m0_s0 --output logs\t1\_console\health_m0_s0_5k.json
python -B -m experiments.t1_pretrain_checks stats logs/t1/_snap5k/t1_m1_s0 --output logs\t1\_console\health_m1_s0_5k.json
```

说明：冻结提交中，诊断脚本的 `reload` 子命令训练中途不可用（它要求 `final.zip` 已存在），对正在写入的日志直接运行 `stats` 也可能遇到不完整的末行，所以 5k 检查改用上面两段命令。训练与评估代码不受影响，上层不因此移动冻结 SHA。

**跟踪项（用户要求，只描述、不作停机条件）**，从 `stats` 输出中摘录：

- 开局择时：a₀ → 请求 τ → 生效 τ 的分布，以及不同生效 τ 的个数；
- 计划管理：新规划、保持、顺延、悬停的占比；
- M1 有效辅助样本率：按决策类型分，并单列"保持计划"与"改变/开始计划"两类；
- 失败原因：按违规类型分，以及结束阶段。

**交付：** `lower/handoffs/t1_round1_20261012/HEALTH_5K_SEED0.md`。1–6 全部通过就释放批 2；任何一项不通过，停下上报。

### 4.3 批 2：种子 1、2

在并发 N 允许的范围内启动。命令同 4.1，把 `--seed 0` / `_s0` 换成 1 / `_s1`、2 / `_s2`。**M0 与 M1 必须成对启动**；N 不够时先启动种子 1 的一对，有训练结束后再启动种子 2 的一对。批 2 不再做健康检查，但第 5 节的异常处理照常适用。

---

## 5. 异常与停机（预先写定，不临场决定）

| 情况 | 处置 |
|---|---|
| 训练进程崩溃、断电、被系统结束 | 该条作废：保留目录，写 `INTERRUPTED.md`（时间、最后一次心跳、原因）。**不从 .zip 续训**（.zip 不含 Replay 和随机数状态）。用同一种子从零重跑，run-name 加后缀 `_r1`。成对的另一条不受影响。作废和重跑都要上报 |
| 出现 `ABORTED.json`（参数非有限） | 技术停机：保留全部产物并上报；不改参数、不换种子、不自行重跑 |
| 评估监视进程崩溃 | 重启同一条 `--watch` 命令（已完成的回合会自动跳过） |
| 资源不足，或 s/决策超过 1.5 倍探针值 | 暂停新的启动，正在跑的不动；上报 |
| 外推总量超过 120 CPU·h，或单条墙钟超过 36 h | 上报 |
| 成绩好或坏 | **不是**停机理由。不得调整奖励、网络、门控、训练预算或种子，不得挑选或删除种子 |

---

## 6. 完成后交付（六条训练及其评估全部结束后）

```powershell
python -B -m experiments.t1_learning_readout --m0 logs/t1/t1_m0_s0 logs/t1/t1_m0_s1 logs/t1/t1_m0_s2 --m1 logs/t1/t1_m1_s0 logs/t1/t1_m1_s1 logs/t1/t1_m1_s2 --output logs\t1\learning_readout.json
foreach ($r in "t1_m0_s0","t1_m0_s1","t1_m0_s2","t1_m1_s0","t1_m1_s1","t1_m1_s2") { python -B -m experiments.t1_pretrain_checks stats logs/t1/$r --output logs\t1\$r\stats_final.json }
```

**交付到** `lower/handoffs/t1_round1_20261012/FINAL.md` 及同目录下的小文件：

- 六组训练各自的：`manifest.json`、`episodes.jsonl`、`decisions.jsonl`（gzip 压缩）、`heartbeat.json`、`finished.json`、`stats_final.json`、`dev_eval` 下全部 JSON；M1 另加 `cf_stats.json` 与各检查点的 `*_cf_stats.json`；
- `learning_readout.json`：配对学习曲线、AUC、首次达到规则水平，以及与规则基准的比较；
- 本机规则基准 `_rule_local/summary.json`；
- 全部文件的 SHA256SUMS；模型 `.zip` 只列出 SHA-256，**不上传**；
- 实验总账中 T1_ROUND1 一行的下层列（`local_result_path`、`local_sha_verified`）。

**交付后停止。** 是否进入独立正式评估（正式块 300000 起），由用户另行决定。

---

## 7. 必须遵守的表述限制（用户特别记录）

M1 在开局择时阶段的辅助门控通过率只有约 4%，这是已知的研究局限。**任何交付和报告都不得把计划管理（途中保持/重规划）上的改善表述为开局择时机制的学习优势。** 报告有效辅助样本率时必须按决策类型分开列出，不得只报总体比例。
