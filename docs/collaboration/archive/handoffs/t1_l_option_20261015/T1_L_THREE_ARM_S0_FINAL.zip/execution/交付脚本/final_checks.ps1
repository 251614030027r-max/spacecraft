﻿$ErrorActionPreference='Continue'
$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1';$env:OPENBLAS_NUM_THREADS='1'
Set-Location -LiteralPath 'D:/py/DRL2_T1_L'
$topic='C:/Users/35884/Documents/Spacecraft/过程文件/T1-L三臂支线_20261015'
$logroot='logs/t1_l_option_20261015'
@{phase='FINAL_CHECKS_RUNNING';shell_pid=$PID;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath "$topic/记录/DELIVERY_FINAL_STATE.json" -Encoding utf8
foreach($arm in 'b2','n0','ndelta') {
 foreach($mode in 'stats','reload') {
  $output=if($mode -eq 'stats') {"$logroot/${arm}_s0/stats_final.json"} else {"$logroot/${arm}_s0/reload.json"}
  & 'D:/py/DRL2/.venv/Scripts/python.exe' -B -m experiments.t1_pretrain_checks $mode "$logroot/${arm}_s0" --output $output 1> "$topic/日志/final_${arm}_${mode}.out" 2> "$topic/日志/final_${arm}_${mode}.err"
  if($LASTEXITCODE -ne 0) { @{phase='FINAL_CHECKS_ERROR';arm=$arm;mode=$mode;exit_code=$LASTEXITCODE;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath "$topic/记录/DELIVERY_FINAL_STATE.json" -Encoding utf8; exit 1 }
 }
}
& 'D:/py/DRL2/.venv/Scripts/python.exe' -B -m experiments.t1_l_readout --runs 'b2=logs/t1_l_option_20261015/b2_s0,n0=logs/t1_l_option_20261015/n0_s0,ndelta=logs/t1_l_option_20261015/ndelta_s0' --rules "$logroot/rules" --strong 'rule:earliest_k1.0_v0.02' --pure "$logroot/pure" --output "$logroot/readout_final.json" 1> "$topic/日志/final_readout.out" 2> "$topic/日志/final_readout.err"
$code=$LASTEXITCODE
@{phase=$(if($code -eq 0){'FINAL_CHECKS_READY_FOR_PACKAGING'}else{'FINAL_CHECKS_ERROR'});readout_exit=$code;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath "$topic/记录/DELIVERY_FINAL_STATE.json" -Encoding utf8
