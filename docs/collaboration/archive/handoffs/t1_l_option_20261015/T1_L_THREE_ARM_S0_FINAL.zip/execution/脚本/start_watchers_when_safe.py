"""One-shot watcher admission only. Never starts/restarts or changes training."""
import json
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent.parent
SCI = Path('D:/py/DRL2_T1_L')
STATE = ROOT / '记录/WATCH_GATE_STATE.json'
LOCK = ROOT / '记录/WATCH_GATE.lock'
M2_PID = 13812

def write(phase, **extra):
    STATE.write_text(json.dumps({'phase': phase, 'pid': psutil.Process().pid,
        'utc': datetime.now(timezone.utc).isoformat(), **extra}, ensure_ascii=False, indent=2), encoding='utf-8')

with LOCK.open('x', encoding='utf-8') as f:
    f.write(str(psutil.Process().pid))
try:
    try:
        m2 = psutil.Process(M2_PID)
        assert 'train.train_t1' in m2.cmdline() and 't1v4_m2_s0' in m2.cmdline()
        identity = m2.create_time()
    except psutil.NoSuchProcess:
        identity = None
    started = []
    for arm in ('b2', 'n0', 'ndelta'):
        receipt = ROOT / f'记录/watch_{arm}_LAUNCH.json'
        assert not receipt.exists(), f'Watcher launch already exists: {arm}; inspect instead of competing.'
        while True:
            alive = False
            if identity is not None:
                try:
                    p = psutil.Process(M2_PID)
                    alive = p.create_time() == identity and p.is_running()
                except psutil.NoSuchProcess:
                    pass
            available = psutil.virtual_memory().available / 1e9
            # Engineering import-memory reserve, not an experimental criterion.
            reserve = 2.2 if not started else 2.0
            if not alive and available >= reserve:
                break
            write('WAITING_FOR_MEMORY_AND_V4_M2_EXIT', m2_alive=alive,
                  available_gb=available, required_import_reserve_gb=reserve, started=started)
            time.sleep(60)
        run = SCI / f'logs/t1_l_option_20261015/{arm}_s0'
        assert (run / 'manifest.json').exists()
        if (run / 'ABORTED.json').exists():
            write('TRAIN_ABORTED_SKIP_WATCH', arm=arm, started=started)
            continue
        script = ROOT / f'脚本/job_watch_{arm}.ps1'
        cmd = ['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile',
               '-NonInteractive', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', str(script)]
        # Keep a real inherited hidden console, matching the verified native PS launch.
        # A no-console parent could cause a later scientific child to allocate a console.
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = subprocess.SW_HIDE
        shell = subprocess.Popen(cmd, cwd=SCI, startupinfo=startup)
        psutil.Process(shell.pid).nice(psutil.IDLE_PRIORITY_CLASS)
        rec = {'arm': arm, 'shell_pid': shell.pid, 'utc': datetime.now(timezone.utc).isoformat(),
               'priority': 'Idle', 'script': str(script), 'command':
               f'D:/py/DRL2/.venv/Scripts/python.exe -B -m experiments.t1_l_eval --watch logs/t1_l_option_20261015/{arm}_s0 --workers 1'}
        receipt.write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding='utf-8')
        started.append(rec)
        write('STARTING_WATCHERS', started=started, available_before_launch_gb=available)
        time.sleep(60)
    write('ALL_WATCHERS_LAUNCHED', started=started)
except BaseException as e:
    write('ERROR', error=repr(e))
    raise
