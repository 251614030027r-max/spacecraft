"""Single external controller for the authorized frozen T1-O V2 gates, revision 2."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
import psutil

TOPIC=Path(__file__).resolve().parent.parent
SCI=Path('D:/py/DRL2_T1_O')
LOG=SCI/'logs/t1o_v2'
COMMIT='d3902a9dd62dbef6cb318e36ff4c2527d7340ec9'
W=max(1,psutil.cpu_count(logical=False)-1)
ENV={**os.environ,'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
START=time.monotonic()
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,x):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)
def state(phase,**kw):write(TOPIC/'记录/STATE.json',dict(phase=phase,pid=os.getpid(),utc=now(),scientific_commit=COMMIT,workers=W,wall_s=time.monotonic()-START,**kw))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(SCI),*args],text=True,encoding='utf-8').strip()
def run(name,args,out=None):
    out=out or TOPIC/'日志'/f'{name}.log'
    command=[sys.executable,'-B',*args]
    start=time.monotonic();minimum_available=psutil.virtual_memory().available
    with out.open('wb') as f:
        p=subprocess.Popen(command,cwd=SCI,env=ENV,stdout=f,stderr=subprocess.STDOUT)
        record=dict(job=name,pid=p.pid,command=command,cwd=str(SCI),utc=now(),log=str(out))
        write(TOPIC/'记录/CHILD_LATEST.json',record);state('RUNNING',job=name,child_pid=p.pid)
        while True:
            try:code=p.wait(timeout=60);break
            except subprocess.TimeoutExpired:
                memory=psutil.virtual_memory();minimum_available=min(minimum_available,memory.available)
                write(TOPIC/'记录/RESOURCE_LATEST.json',dict(utc=now(),job=name,available_bytes=memory.available,min_available_bytes=minimum_available,memory_percent=memory.percent,disk_free=psutil.disk_usage('D:/').free))
    record.update(exit_code=code,finished_utc=now(),wall_s=time.monotonic()-start,min_available_bytes=minimum_available)
    write(TOPIC/'记录'/f'{name}_RECEIPT.json',record)
    return code

with (TOPIC/'记录/EXECUTE.lock').open('x') as f:f.write(str(os.getpid()))
try:
    assert git('rev-parse','HEAD')==COMMIT
    assert not git('status','--porcelain'),'new science tree must be clean'
    assert psutil.disk_usage('D:/').free>=20_000_000_000
    assert not LOG.exists(),'existing output: inspect before any restart'
    LOG.mkdir(parents=True)
    deps={}
    for name in ('requirements.txt','requirements-mpc.txt','requirements-dev.txt'):
        old=Path('D:/py/DRL2_T1_L')/name;new=SCI/name
        assert old.read_bytes().replace(b'\r\n',b'\n')==new.read_bytes().replace(b'\r\n',b'\n'),name
        deps[name]=dict(old_sha=sha(old),new_sha=sha(new),lf_equal=True)
    expected={
      't1o_p2_discovery_openings.json':'663e8ed9cbbfcc30f07fb04419fb6f74c5f5d887e6b9387e2c7c32450ec45070',
      't1o_p2_confirmation_openings.json':'2ff5e9cc45592f3534878e08fb259d9a68ed1577bb23b54361220df842c03e47',
      't1o_p2_development_openings.json':'79d1505ce0b838da347f18363b2f06f1c89b03be59630ac0f927e932cd542f9e'}
    for name,h in expected.items():assert sha(SCI/'experiments'/name)==h,name
    write(TOPIC/'记录/STATIC_CHECKS.json',dict(commit=COMMIT,openings=expected,dependencies=deps,disk_free=psutil.disk_usage('D:/').free,utc=now()))
    tests=('test_t1_o','test_t1_l_s','test_t1_l','test_t1_counterfactual','test_t1_gym','test_t1_termination','test_t1_fixes','test_t1_m1')
    (TOPIC/'测试临时').mkdir(exist_ok=True)
    assert run('pytest',['-m','pytest','-q','-p','no:cacheprovider',*[f'tests/{n}.py' for n in tests],'--basetemp',str(TOPIC/'测试临时/pytest')])==0,'Admission pytest failed'
    result=(TOPIC/'日志/pytest.log').read_text(encoding='utf-8',errors='replace')
    assert re.search(r'\b106 passed\b',result),'Expected 106 passed'
    archive=SCI/'evidence/T1O_V2/gate_a'
    verified={}
    for line in (archive/'SHA256SUMS').read_text().splitlines():
        h,name=line.split(None,1);name=name.strip().lstrip('*');assert sha(archive/name)==h,name;verified[name]=h
    # Validate every archive target, reject links, and extract only within this log root.
    with tarfile.open(archive/'episodes.tar.gz','r:gz') as tar:
        for member in tar.getmembers():
            target=(LOG/member.name).resolve()
            assert target.is_relative_to(LOG.resolve()),member.name
            assert member.isdir() or member.isfile(),member.name
        tar.extractall(LOG,filter='data')
    count=len(list((LOG/'gate_a').rglob('*.json')));assert count==160,count
    shutil.copy2(archive/'gate_a.json',LOG/'gate_a.json');assert sha(LOG/'gate_a.json')==verified['gate_a.json']
    write(TOPIC/'记录/GATE_A_ARCHIVE_RECEIPT.json',dict(source_commit=COMMIT,source=str(archive),verified_sha256=verified,episodes=count,reproduced=False,utc=now()))
    (LOG/'ADMISSION.md').write_text('# T1-O V2 第2版本机准入\n\n科学'+COMMIT+'；指定测试106 passed；三份开局原始SHA匹配；磁盘≥20GB；依赖与旧冻结T1-L逐文件LF规范化相同，原始SHA见STATIC_CHECKS。浅克隆缺基线对象，未把文件对比冒充git diff。无包改动。Gate A仅复用经SHA256SUMS核验的上层存档，160回合，未重算；源哈希见GATE_A_ARCHIVE_RECEIPT。\n',encoding='utf-8')
    cpu=subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command','(Get-CimInstance Win32_Processor).Name'],text=True).strip()
    (LOG/'SCHEDULE.md').write_text(f'# 本机调度\n\nUTC {now()}；CPU {cpu}；物理核{psutil.cpu_count(logical=False)}、逻辑线程{psutil.cpu_count()}，按执行单物理核−1选择W={W}。Normal优先级，OMP/MKL/OPENBLAS=1；全部新后台窗口隐藏。\n\n冻结chain给C/零步/E传入W；Gate B入口不暴露workers参数，内部冻结默认4个工作进程，因此B实际4路，不改代码或追加禁用参数。墙钟为资源记录，不是实时性声明或OS累计CPU时间。\n',encoding='utf-8')
    state('ADMISSION_PASSED_ARCHIVE_VERIFIED_CHAIN_STARTING',gate_a_episodes=count)
    code=run('chain',['-m','experiments.t1o_v2_chain','--root','logs/t1o_v2','--workers',str(W)],SCI/'logs/t1o_v2_chain.log')
    chain=load(LOG/'CHAIN.json') if (LOG/'CHAIN.json').exists() else None
    state('CHAIN_STOPPED' if code==0 else 'CHAIN_TECHNICAL_ERROR',exit_code=code,chain=chain)
except Exception:
    state('STOPPED_ERROR',error=traceback.format_exc())
finally:
    # Deliver facts on either pass, scientific fail or technical stop, never expand to D.
    code=subprocess.call([sys.executable,'-B',str(TOPIC/'脚本/deliver.py')],env=ENV)
    if code:state('PUBLICATION_ERROR',delivery_exit=code,scientific_tasks_not_restarted=True)
