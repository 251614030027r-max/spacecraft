﻿$ErrorActionPreference='Continue'
Set-Location -LiteralPath 'D:\py\DRL2_T1_L'
$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1';$env:OPENBLAS_NUM_THREADS='1'
(Get-Process -Id $PID).PriorityClass='Idle'
Add-Type -Namespace Win32 -Name ConsoleCheck -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);'
$h=[Win32.ConsoleCheck]::GetConsoleWindow()
@{shell_pid=$PID;utc=[DateTime]::UtcNow.ToString('o');console_hwnd=$h.ToInt64();visible=[Win32.ConsoleCheck]::IsWindowVisible($h)} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\train_n0_WINDOW.json' -Encoding utf8
& 'D:\py\DRL2\.venv\Scripts\python.exe' -B -m train.train_t1_option --arm n0 --steps 40000 --seed 0 --run-name n0_s0 --log-root logs/t1_l_option_20261015 --n-envs 1 1> 'logs/t1_l_option_20261015/train_n0.out' 2> 'logs/t1_l_option_20261015/train_n0.err'
$exitcode=$LASTEXITCODE
@{shell_pid=$PID;exit_code=$exitcode;finished_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\train_n0_RECEIPT.json' -Encoding utf8