﻿$ErrorActionPreference='Continue'
Set-Location -LiteralPath 'D:\py\DRL2_T1_L'
$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1';$env:OPENBLAS_NUM_THREADS='1'
(Get-Process -Id $PID).PriorityClass='Idle'
Add-Type -Namespace Win32 -Name ConsoleCheck -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);'
$h=[Win32.ConsoleCheck]::GetConsoleWindow()
@{shell_pid=$PID;utc=[DateTime]::UtcNow.ToString('o');console_hwnd=$h.ToInt64();visible=[Win32.ConsoleCheck]::IsWindowVisible($h)} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\rule_k1.0_v0.02_WINDOW.json' -Encoding utf8
& 'D:\py\DRL2\.venv\Scripts\python.exe' -B -m experiments.t1_l_eval --policy 'rule:earliest_k1.0_v0.02' --output-dir 'logs/t1_l_option_20261015/rules/rule_k1.0_v0.02' --workers 1 1> 'logs/t1_l_option_20261015/rule_k1.0_v0.02.out' 2> 'logs/t1_l_option_20261015/rule_k1.0_v0.02.err'
$exitcode=$LASTEXITCODE
@{shell_pid=$PID;exit_code=$exitcode;finished_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath 'C:\Users\35884\Documents\Spacecraft\过程文件\T1-L三臂支线_20261015\记录\rule_k1.0_v0.02_RECEIPT.json' -Encoding utf8