# T1-O V2 第2版本机准入

科学d3902a9dd62dbef6cb318e36ff4c2527d7340ec9；指定测试106 passed；三份开局原始SHA匹配；磁盘≥20GB；依赖与旧冻结T1-L逐文件LF规范化相同，原始SHA见STATIC_CHECKS。浅克隆缺基线对象，未把文件对比冒充git diff。无包改动。Gate A仅复用经SHA256SUMS核验的上层存档，160回合，未重算；源哈希见GATE_A_ARCHIVE_RECEIPT。
