import pathlib,os,subprocess,json,datetime,time,hashlib,sys
ROOT=pathlib.Path('D:/py/DRL2_T1');TOPIC=pathlib.Path(__file__).resolve().parent.parent;RECORD=TOPIC/'记录';PYTHON='D:/py/DRL2/.venv/Scripts/python.exe'
RUN=ROOT/'logs/t1/t1v2_m1_s0_r1';DIAG=ROOT/'logs/t1/_diag';DIAG.mkdir(exist_ok=True)
ENV=os.environ.copy()
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:ENV[key]='1'
ENV['PYTHONUNBUFFERED']='1';ENV['PYTHONIOENCODING']='utf-8'
def dump(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def state(step,**extra):dump(RECORD/'STATE.json',{'step':step,'pid':os.getpid(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra})
def execute(name,args):
    command=[PYTHON,'-B',*args];state(name,status='RUNNING',command=command)
    start=time.perf_counter()
    with (RECORD/f'{name}.out.txt').open('wb') as out,(RECORD/f'{name}.err.txt').open('wb') as err:
        p=subprocess.Popen(command,cwd=ROOT,env=ENV,stdout=out,stderr=err)
        dump(RECORD/'CHILD_LATEST.json',{'stage':name,'pid':p.pid,'command':command});code=p.wait()
    receipt={'command':command,'exit_code':code,'wall_s':time.perf_counter()-start};dump(RECORD/f'{name}_receipt.json',receipt)
    if code:raise RuntimeError(f'{name} failed; preserve output and report')
    return receipt
def spot(label):
    a=json.loads((DIAG/f'p1/{label}_A_295001.json').read_text());mark={'0k':0,'20k':20000,'30k':30000}[label];old=json.loads((RUN/f'dev_eval/{mark}/295001.json').read_text())
    checks={'event':a['event']==old['event'],'return_bitwise':a['discounted_return_from_k']==old['discounted_return'],'time':a['time_s']==old['time_s'],'delta_v':a['delta_v_m_s']==old['delta_v_m_s']}
    dump(RECORD/f'SPOT_{label}.json',{'checks':checks,'old_return':old['discounted_return'],'new_return':a['discounted_return_from_k']});assert all(checks.values()),f'{label} spot differs: {checks}'
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='ca82c637c0110e96910d87e3302f4fca18e03215'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
    assert not subprocess.check_output(['git','diff','--stat','78eb63c','ca82c637c0110e96910d87e3302f4fca18e03215','--','env','train','experiments/t1_dev_eval.py'],cwd=ROOT,text=True).strip()
    refs=json.loads(pathlib.Path('C:/Users/35884/Documents/Spacecraft/过程文件/T1v2种子0验证_20261013/最终证据/MODEL_SHA256.json').read_text(encoding='utf-8'))
    hashes=[]
    for step in [0,20000,30000]:
        p=RUN/f'checkpoints/m1_{step}_decisions.zip';expected=next(x['sha256'] for x in refs if pathlib.Path(x['source']).name==p.name);actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected;hashes.append({'file':str(p),'sha256':actual,'reference_match':True})
    dump(RECORD/'MODEL_SHA_CHECK.json',hashes);(DIAG/'model_sha.txt').write_bytes(''.join(f'{x["sha256"]}  {x["file"]}\n' for x in hashes).encode('utf-8'))
    tmp=TOPIC/'测试临时';tmp.mkdir(exist_ok=True)
    execute('tests',['-m','pytest','-q','tests/test_t1_rootcause_diag.py','tests/test_t1_gym.py','--basetemp',str(tmp/'pytest')])
    cp=lambda n:str(RUN/f'checkpoints/m1_{n}_decisions.zip')
    prefix=['-m','diagnostics.t1_rootcause.interventions']
    execute('pilot_30k_A',prefix+['--checkpoint',cp(30000),'--label','30k','--modes','A','--openings','295001','--output-dir',str(DIAG/'p1')])
    spot('30k');trial=json.loads((DIAG/'p1/30k_A_295001.json').read_text());s=trial['wall_s']/trial['decisions'];estimate=9500*s/3600;dump(RECORD/'COST_GATE.json',{'s_per_decision':s,'estimated_cpu_h_by_order':estimate,'maximum_cpu_h':6.5,'passed':estimate<=6.5,'pilot':trial['wall_s'],'pilot_decisions':trial['decisions']})
    if estimate>6.5:state('COST_GATE',status='STOPPED_COST_LIMIT',estimated_cpu_h=estimate);sys.exit(0)
    openings='295001,295002,295010,295015,295019,295000,295003,295004'
    execute('p1_30k',prefix+['--checkpoint',cp(30000),'--label','30k','--modes','B,C,D','--openings',openings,'--output-dir',str(DIAG/'p1'),'--workers','10'])
    execute('p1_20k_spot',prefix+['--checkpoint',cp(20000),'--label','20k','--modes','A,B,C,D','--openings','295001','--output-dir',str(DIAG/'p1')]);spot('20k')
    execute('p1_20k',prefix+['--checkpoint',cp(20000),'--label','20k','--modes','B,C,D','--openings',openings,'--output-dir',str(DIAG/'p1'),'--workers','10'])
    execute('p1_0k_spot',prefix+['--checkpoint',cp(0),'--label','0k','--modes','A,C','--openings','295001','--output-dir',str(DIAG/'p1')]);spot('0k')
    execute('p1_0k',prefix+['--checkpoint',cp(0),'--label','0k','--modes','C','--openings',openings,'--output-dir',str(DIAG/'p1'),'--workers','10'])
    cps=','.join(f'{label}={cp(n)}' for label,n in [('0k',0),('20k',20000),('30k',30000)])
    prefix2=['-m','diagnostics.t1_rootcause.critic_probe','probe','--states','diagnostics/t1_rootcause/states.json','--checkpoints',cps,'--followups','rule,traj_det','--output-dir',str(DIAG/'p2')]
    execute('p2_verify',prefix2+['--only','0,1','--verify-branch','--workers','2'])
    execute('p2_remaining',prefix2+['--only','4,5,8,9,12,13,16,17','--workers','8'])
    execute('analyze',['-m','diagnostics.t1_rootcause.analyze','--interventions',str(DIAG/'p1'),'--dev-eval',str(RUN/'dev_eval'),'--rule','logs/t1/_v2/rule_local','--probe',str(DIAG/'p2'),'--output',str(DIAG/'diag_readout.json')])
    state('COMPLETE',status='RAW_RESULTS_READY')
except Exception as e:
    state('ERROR',status='STOPPED_ERROR',error=repr(e));raise
